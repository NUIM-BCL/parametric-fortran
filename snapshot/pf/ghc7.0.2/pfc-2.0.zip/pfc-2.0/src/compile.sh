ghc --make -O -fglasgow-exts -fallow-overlapping-instances -fallow-undecidable-instances Main -o ../bin/pfc
 
