ghc --make -O -fglasgow-exts -fallow-overlapping-instances -fallow-undecidable-instances -package lang Main -o ../bin/pfc
 
